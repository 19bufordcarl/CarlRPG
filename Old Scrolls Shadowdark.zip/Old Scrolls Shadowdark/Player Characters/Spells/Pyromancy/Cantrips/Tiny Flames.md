# Tiny Flames

*Cantrip*

**Duration:** Instant

**Range:** 5 feet

**School:** Pyromancy

This spell creates a small gout of flames at a single target dealing damage equal to your level.
