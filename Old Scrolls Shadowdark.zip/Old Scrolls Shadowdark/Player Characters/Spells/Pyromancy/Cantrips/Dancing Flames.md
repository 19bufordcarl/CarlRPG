# Dancing Flames

*Cantrip*

**Duration:** 3 rounds per pyromancer level

**Range:** 30 feet

**School:** Pyromancy

You create a torch-size harmless mote of flame within range that hovers for the duration. As an action you can move the motes up to 30 feet.
