# Wall of Flames

**Duration:** 3 rounds per level

**Range:** Self

**School:** Pyromancy

This spell creates a magical wall of fire that extends up to a near distance in length. It is 5 feet thick and deals 1d6 fire damage per level to anyone trying to pass through it. This will also ignite any carried combustible items, such as books or scrolls.

Unintelligent animals will not attempt to pass through the wall.
