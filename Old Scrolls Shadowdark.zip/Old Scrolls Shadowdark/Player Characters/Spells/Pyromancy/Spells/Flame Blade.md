# Flame Blade

**Duration:** 4 rounds per level

**Range:** Self

**School:** Pyromancy

This spell conjures a flaming weapon of your choice in your hand. It strikes with a +1 bonus and deals 1d8 damage. At 4th level, raise this to a +2 bonus and 2d8 damage. At 7th level, raise this to a +3 bonus and 3d8 damage.
