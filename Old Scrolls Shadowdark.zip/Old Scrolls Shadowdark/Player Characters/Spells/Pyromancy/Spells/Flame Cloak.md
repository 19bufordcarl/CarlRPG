# Flame Cloak

**Duration:** Focus

**Range:** Self

**School:** Pyromancy

This spell cloaks the caster in 5 feet of raging flames that hurt anyone who approaches. Whenever a creature starts their turn, ends their turn, or enters the area with the flames, they take fire damage equal to the caster's level.
