# Flame Whip

**Duration:** Instant

**Range:** 30 feet

**School:** Pyromancy

This spell creates a flame-cloaked whip that lashes out at your command toward a creature in range. They take 1d6 fire damage per level and if the creature is not too big you can pull it up to 10 feet closer to you.
