# Fireball

**Duration:** Instant

**Range:** 120 feet

**School:** Pyromancy

You hurl a small flame that erupts into a fiery blast. All creatures in a near-sized cube around where the flame lands take 1d6 damage per level.
