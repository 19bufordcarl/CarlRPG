# Flames

**Duration:** Instant

**Range:** 5 feet

**School:** Pyromancy

This spell projects a cloud of scorching ash and flame from your fingertips onto a single target. They take 1d6 fire damage per level.
