# Fire Rune

**Duration:** Until rest

**Range:** 5 feet

**School:** Pyromancy

This spell creates an invisible magical symbol on a surface, container, or door. It cannot be removed. Touching the rune will trigger it and douse the victim in fire. They take 1d6 fire damage each round for 1 round per level.
