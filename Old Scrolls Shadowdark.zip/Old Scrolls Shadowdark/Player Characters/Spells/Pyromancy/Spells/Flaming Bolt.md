# Flaming Bolt

**Duration:** Instant

**Range:** 120 feet

**School:** Pyromancy

This spell projects a flaming magical arrow towards a single target. It must have a clear path of travel with no obstructions. It deals 1d6 fire damage per level.
