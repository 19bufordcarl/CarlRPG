# Flame Ward

**Duration:** Focus

**Range:** 5 feet

**School:** Pyromancy

This spell will reduce all fire or frost damage taken by 3 as long as you focus. If you take 4 or more fire or frost damage from a single source, you will lose focus and the spell will end.

The amount of damage increases by 1 for every 2 levels up to a max of 8 at level 10.
