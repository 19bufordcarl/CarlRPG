# Spellcasting

When you cast a spell, you invoke magic to cause an effect. Casting a spell takes your action. Characters with the spellcasting talent can cast spells.

To cast a spell you know, expend 1 mana point and make a spellcasting check by rolling 1d20 + your Spellcasting ability modifier.

If you succeed on your spellcasting check, the spell takes effect.

If you fail your spellcasting check, the spell does not take effect. The mana point is still spent.

## Critical Success

If you roll a natural 20 on your spellcasting check, you may double one of the spell's numerical effects. This remains in effect on a focus spell until your next focus check.

## Critical Failure

If you roll a natural 1 on your spellcasting check, the spell does not take effect. If it was a focus spell, the spell immediately ends.

## Cantrips

Cantrips are simple spells that can always be cast without expending mana points and do not require a spellcasting check.
