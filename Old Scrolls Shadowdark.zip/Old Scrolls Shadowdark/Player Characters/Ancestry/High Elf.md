# High Elf

Natives of idyllic Somerset, know for being magically inclined.

**Highborn.** You have advantage on checks made to avoid spells.
