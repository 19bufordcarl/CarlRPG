# Pyromancer

Experts of wielding magical flames.

**HP:** Starts at 4. Then 1d4 per level.

**Spellcasting.** You can cast pyromancy spells you know. Choose Intelligence, Wisdom, or Charisma as your spellcasting ability when you become a pyromancer.

**Learning Spells.** You can permanently learn a Pyromancy spell from a spell scroll by studying it for a day and succeeding on a DC 10 + X Intelligence check where X is the tier of the spell.

Whether you succeed or fail you expend the spell scroll. Spells you learn in this way don't count toward your known spells.

## Pyromancy Talents

| Class Level |                Talent                |
| :---------: | :----------------------------------: |
|      1      |     +2 to your spellcasting stat     |
|      2      |                  --                  |
|      3      |                  --                  |
|      4      |          +2 to any stat(s)           |
|      5      |                  --                  |
|      6      |   Gain advantage fire damage rolls   |
|      7      |                  --                  |
|      8      | +1 to pyromancer spellcasting checks |
|      9      |                  --                  |
|     10      |         Make a custom spell!         |

## Pyromancy Spell Table

| Class Level | Known Cantrips | Known Spells | Mana Points |
| :---------: | :------------: | :----------: | :---------: |
|      1      |       1        |      2       |      3      |
|      2      |       1        |      2       |      4      |
|      3      |       1        |      3       |      5      |
|      4      |       2        |      3       |      6      |
|      5      |       2        |      4       |      7      |
|      6      |       2        |      4       |      8      |
|      7      |       2        |      5       |      9      |
|      8      |       2        |      5       |     10      |
|      9      |       2        |      6       |     11      |
|     10      |       2        |      6       |     12      |

## Pyromancy Spell Learning
